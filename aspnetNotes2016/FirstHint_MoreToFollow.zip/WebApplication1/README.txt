This example shows several techniques needed to complete assignment 1.

This example shows how to work with custom types which include columns from more 
than one entity.  The custom type is defined using a 'View Model' class.
When the view is added using the wizard the view model class is selected
but a database context is not selected.

To build this example, add an entity data model for the FoodStore database
to the project.

More detail on how this project is built will follow.
