﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Repositories;
using WebApplication1.ViewModels;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            EmployeeStoreRepo esRepo = new EmployeeStoreRepo();
            IEnumerable<EmployeeStoreVM> es = esRepo.GetAll();
            List<EmployeeStoreVM> esList = es.ToList();
            return View(es);
        }

        public ActionResult Details(int employeeID, string branch) {
            EmployeeStoreRepo esRepo = new EmployeeStoreRepo();
            EmployeeStoreVM esVM =  esRepo.Get(employeeID, branch);
            return View(esVM);
        }

        // This method is called when the user arrives at the edit page.
        [HttpGet]
        public ActionResult Edit(int employeeID, string branch) {
            EmployeeStoreRepo esRepo = new EmployeeStoreRepo();
            EmployeeStoreVM esVM =  esRepo.Get(employeeID, branch);
            return View(esVM);
        }

        // This method is called when the user clicks the submit
        // button from the edit page.
        [HttpPost] 
        public ActionResult Edit(EmployeeStoreVM esVM) {
            EmployeeStoreRepo esRepo = new EmployeeStoreRepo();
            esRepo.Update(esVM);

            // go to index action method.
            return RedirectToAction("Index", "Home");
        }
    }
}