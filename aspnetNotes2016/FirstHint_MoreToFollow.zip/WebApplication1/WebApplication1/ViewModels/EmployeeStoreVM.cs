﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.ViewModels {
    // A view model is just a custom model with properties from 
    // more than one entity.

    // There is no logic in the view model.
    public class EmployeeStoreVM {
        public int    EmployeeID { get; set; }
        public string LastName  { get; set; }
        public string FirstName { get; set; }
        public string Branch    { get; set; }
        public string Region    { get; set; }
        public string BuildingName { get; set; }
        public int    UnitNum   { get; set; }
    }
}