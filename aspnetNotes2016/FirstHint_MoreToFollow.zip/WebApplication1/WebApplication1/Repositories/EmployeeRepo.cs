﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Repositories {
    // All CRUD for Employees.
    public class EmployeeRepo {
        public bool Update(int id, string first, 
                           string last) {
            FoodStoreEntities db = new FoodStoreEntities();
            Employee employee = db.Employees
                .Where(e=>e.employee_id == id)
                .FirstOrDefault();
            // Remember you can't update the primary key without 
            // causing trouble.  Just update the first and last names
            // for now.
            employee.first_name = first;
            employee.last_name  = last;
            db.SaveChanges();
            return true;
        }

        public Employee Get(int id) {
            FoodStoreEntities db = new FoodStoreEntities();
            return db.Employees.Where(e=>e.employee_id == id)
                     .FirstOrDefault();
        }
    }
}