﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication1.ViewModels;

namespace WebApplication1.Repositories {
    // The EmployeeStore has methods for initiating CRUD for this custom type.
    public class EmployeeStoreRepo {
        public IEnumerable<EmployeeStoreVM> GetAll() {
            FoodStoreEntities db = new FoodStoreEntities();
            IEnumerable<EmployeeStoreVM> esList 
                = db.Employees.Where(es=>es.Store.branch == es.branch)
                    // Assign properties within the 'Select' statement.
                    // Notice how we 'must' use the 'EmployeeStoreVM' type.
                    .Select(es => new EmployeeStoreVM() {
                         EmployeeID   = es.employee_id,
                         LastName     = es.last_name,
                         FirstName    = es.first_name,
                         Branch       = es.branch,
                         Region       = es.Store.region,

                         // Handle null values.
                         BuildingName = 
                                 es.Store.building_name == null?"":
                                 es.Store.building_name,
                        
                         // Must handle null because a null exists for 
                         // unit_num in the database.
                         // Get integer if it exists otherwise get 0.
                         UnitNum = es.Store.unit_num == null ? 0 : 
                         (int)es.Store.unit_num
                        });
            return esList;
        }

        public EmployeeStoreVM Get(int employeeID, string branch) {
            // Get Employee from EmployeeRepo.
            EmployeeRepo employeeRepo = new EmployeeRepo();
            Employee   employee = employeeRepo.Get(employeeID);

            // Get Store from StoreRepo.
            StoreRepo storeRepo = new StoreRepo();
            Store         store = storeRepo.Get(branch);

            // Merge data into custom view model object.
            EmployeeStoreVM esVM = new EmployeeStoreVM {
                EmployeeID = employee.employee_id,
                LastName   = employee.last_name,
                FirstName  = employee.first_name,
                Branch     = store.branch,
                BuildingName = store.building_name == null?"":
                               store.building_name,
                Region     = store.region,
                // Need condition to handle null
                UnitNum    = store.unit_num == null ? 0 : 
                           (int)store.unit_num
            };
            return esVM;
        }

        public bool Update(EmployeeStoreVM esVM) {
            // Updating our ViewModel really requires updates to 
            // two separate tables. 

            // Update the 'Store'.
            StoreRepo storeRepo = new StoreRepo();
            storeRepo.Update(esVM.Branch, esVM.Region);

            // Update the 'Employee'.
            EmployeeRepo empRepo = new EmployeeRepo();
            empRepo.Update(esVM.EmployeeID, esVM.FirstName, esVM.LastName);
            return true;
        }
    }
}