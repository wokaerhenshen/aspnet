﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Repositories {
    // All CRUD for Stores.
    public class StoreRepo {
        public Store Get(string branch) {
            FoodStoreEntities db = new FoodStoreEntities();
            return db.Stores.Where(s=>s.branch == branch)
                     .FirstOrDefault();
        }

        public bool Update(string branch, string region) {
            FoodStoreEntities db = new FoodStoreEntities();
            Store store = db.Stores.Where(s=>s.branch == branch)
                            .FirstOrDefault();
            // It silly to update a region. But maybe a region
            // like 'BC' is switched to 'Western Canada' or to 'North West'.

            // Due to the primary key 
            // references though there really is no other field that
            // will update nicely for this example so let's just update
            // region now and keep it simple.
            store.region = region;
            db.SaveChanges(); // Commit changes to database.

            // Error handling code goes here.
            return true;
        }
    }
}