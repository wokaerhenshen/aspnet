"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var app_nameservice_1 = require("./app.nameservice");
// This component consumes the re-usable service.
var AppComponent = (function () {
    // Since using a provider above we can receive service.
    function AppComponent(_nameService) {
        this.nameService = _nameService;
    }
    AppComponent.prototype.getData = function () {
        var _this = this;
        this.nameService.getNames()
            .subscribe(
        // Success.
        function (data) {
            _this.names = data;
            console.log(JSON.stringify(data));
        }, 
        // Error.
        function (error) {
            alert(error);
        }, 
        // Final Instructions.
        function () {
            console.log("Finished");
        });
    };
    AppComponent.prototype.postData = function () {
        var _this = this;
        // Some JavaScript
        var FullName = {
            "FirstName": this.firstName,
            "LastName": this.lastName
        };
        this.nameService.postName(FullName)
            .subscribe(
        // Success.
        function (data) {
            // Extract value using name as key.
            _this.fullName = data["FullName"];
            _this.fullNameStatus = data["Status"];
            console.log(JSON.stringify(data));
        }, 
        // Error.
        function (error) {
            alert(error);
        }, 
        // Final instructions.
        function () {
            console.log("Finished");
        });
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: " <a href=\"./Names/Hello\">Go to ASP.NET View</a><br/><br/>\n\n                <button (click)=\"getData()\">GET names</button>\n                <ul>\n                    <li *ngFor=\"let nameObject of names\">\n                       {{nameObject.first}} {{nameObject.last}}\n                    </li>\n                </ul>\n                <hr>\n\n                <!-- Post name -->\n                First Name: <input [(ngModel)]=\"firstName\"><br/>\n                Last Name:  <input [(ngModel)]=\"lastName\">\n                <button (click)=\"postData()\">POST Name</button>\n\n                <!-- Show result from Post -->\n                <div *ngIf=\"fullName\">Full Name: {{fullName}}<br/>\n                Status: {{fullNameStatus}}</div>\n                ",
        // Providers allow us to inject an object instance through the constructor.
        providers: [app_nameservice_1.NameService]
    }),
    __metadata("design:paramtypes", [app_nameservice_1.NameService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map