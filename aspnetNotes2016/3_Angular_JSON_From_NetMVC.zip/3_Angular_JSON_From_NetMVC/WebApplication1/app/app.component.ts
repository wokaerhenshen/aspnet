import { Component }      from '@angular/core';
import {  NameService } from './app.nameservice';

// This component consumes the re-usable service.
@Component({
    selector: 'my-app',
    template: ` <a href="./Names/Hello">Go to ASP.NET View</a><br/><br/>

                <button (click)="getData()">GET names</button>
                <ul>
                    <li *ngFor="let nameObject of names">
                       {{nameObject.first}} {{nameObject.last}}
                    </li>
                </ul>
                <hr>

                <!-- Post name -->
                First Name: <input [(ngModel)]="firstName"><br/>
                Last Name:  <input [(ngModel)]="lastName">
                <button (click)="postData()">POST Name</button>

                <!-- Show result from Post -->
                <div *ngIf="fullName">Full Name: {{fullName}}<br/>
                Status: {{fullNameStatus}}</div>
                `,
    // Providers allow us to inject an object instance through the constructor.
    providers: [NameService]
})
export class AppComponent {
    names: Array<any>;
    nameService: NameService;
    firstName: string;
    lastName: string;
    fullName: string;
    fullNameStatus: string;

    // Since using a provider above we can receive service.
    constructor(_nameService: NameService) {
        this.nameService = _nameService;
    }

    getData() {
        this.nameService.getNames()
            // Subscribe to observable.
            .subscribe(
                // Success.
                data => {
                    this.names = data
                    console.log(JSON.stringify(data))
                },
                // Error.
                error => {
                    alert(error)
                },
                // Final Instructions.
                () => {
                    console.log("Finished")
                });
    }

    postData() {  
        // Some JavaScript
        let FullName = {
            "FirstName": this.firstName,
            "LastName": this.lastName
        }

        this.nameService.postName(FullName)
            // Subscribe to observable.
            .subscribe(

            // Success.
            data => {
                // Extract value using name as key.
                this.fullName       = data["FullName"];
                this.fullNameStatus = data["Status"];
                console.log(JSON.stringify(data))
            },
            // Error.
            error => {
                alert(error)
            },
            // Final instructions.
            () => {
                console.log("Finished")
            });
    }
}