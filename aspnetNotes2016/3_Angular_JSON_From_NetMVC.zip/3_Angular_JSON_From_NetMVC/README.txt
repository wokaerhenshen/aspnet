First, move this entire project to D:/Work or a place where
you have full and easy access.

Then, open the solution. Wait for the node_modules to install.
The project knows about them because this element exists in the
*.project file:
<TypeScriptCompileBlocked>true</TypeScriptCompileBlocked>

After the node_modules are downloaded, click on the error filter
(See the funnel icon) in the "Error List" and choose "Select All" 
to remove all typescript errors from the listing.

After, with a command prompt, cd into the app directory where the 
Angular application is. Then run the following to launch the server
and auto-compile the angular code when changes to it are made:
	>npm start

Please note though *** you will not be able to run the application 
from localhost:3000 *** so close this page when it launches to avoid 
confusion. Try to remember to keep the server running though
so your typescript changes compile.

Now run your .NET project.

