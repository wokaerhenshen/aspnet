﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Assignment2Hint.ViewModels {
    public class TaskAssignmentVM {

        // Note these are public and get/set are required.
        public int volunteerID { get; set; }
        public string monthAssigned { get; set; }
    }
}