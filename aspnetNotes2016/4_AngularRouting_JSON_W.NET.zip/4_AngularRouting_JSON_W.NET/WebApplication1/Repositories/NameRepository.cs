﻿// JSON.Net has been downloaded with NuGet package manager.
// It lets us create ad hoc JSON objects.
using Newtonsoft.Json.Linq;

namespace WebApplication1.Repositories {
    public class NameRepository {
        public dynamic GetAll() {
            // Create JSON array of names.
            dynamic names = new JArray();
            dynamic name1 = new JObject(); 
            name1.first   = "Jeff";
            name1.last    = "Boucher";
            names.Add(name1);

            dynamic name2 = new JObject(); 
            name2.first   = "Andrea";
            name2.last    = "Martin";
            names.Add(name2);

            // JSON looks like:
            // {[{ "first": "Jeff",   "last": "Boucher"},
            //   { "first": "Andrea", "last": "Martin"}]}
            return names;
        }

        public dynamic GetFullName(string first, string last) {
            dynamic response  = new JObject();
            response.FullName = first + " " + last;
            response.Status   = "Success";

            // JSON looks like:
            // {"FullName": " - ", "Status": "Error"}
            return response;
        }
    }
}