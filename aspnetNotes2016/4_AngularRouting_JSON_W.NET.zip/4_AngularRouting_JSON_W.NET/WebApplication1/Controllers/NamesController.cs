﻿using System.Web.Mvc;
using WebApplication1.Repositories;
using WebApplication1.Models;
// JSON.Net has been downloaded with NuGet package manager.
// It lets us create adhoc JSON objects.
using Newtonsoft.Json.Linq;

namespace WebApplication1.Controllers
{
    public class NamesController : Controller
    {
        [HttpGet]
        public ActionResult GetNames() {
            NameRepository nameRepo = new NameRepository();
            dynamic names = nameRepo.GetAll();
            // JSON looks like:
            // {[{ "first": "Jeff",   "last": "Boucher"},
            //   { "first": "Andrea", "last": "Martin"}]}
            return Content( names.ToString(), "application/json" );
        }

        [HttpPost]
        // Object passed in needs 'FirstName' and 'LastName' properties.
        public ActionResult GetFullName(FullNameVM nameObj) { 
            dynamic response = new JObject();

            // ModelState.IsValid does server side validation
            // based on validation attributes in the ViewModel.
            if(ModelState.IsValid) { 
                NameRepository nameRepo = new NameRepository();
                response  = nameRepo.GetFullName(nameObj.FirstName, nameObj.LastName);
                    // JSON looks like:
                    // {"FullName": "Jack Spratt", "Status": "Success"}
            }
            else {
                response.FullName = " - " ;
                response.Status = "Error";
                    // JSON looks like:
                    // {"FullName": " - ", "Status": "Error"}
            }
            return Content( response.ToString(), "application/json" );
        }

        [HttpGet]
        public ActionResult Hello() {
            ViewBag.Message = "Hi from ASP.NET";
            return View();
        }
    }
}