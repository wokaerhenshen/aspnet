﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models {
    public class FullNameVM {
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
    }
}