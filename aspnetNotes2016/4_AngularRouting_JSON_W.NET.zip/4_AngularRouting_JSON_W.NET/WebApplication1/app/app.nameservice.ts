import { Injectable }     from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable }     from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw'; // This is needed for error handling.

@Injectable()
export class NameService {
    constructor(private http: Http) { }

    // GET name list from ASP.NET.
    getNames(): Observable<string[]> {
        let dataUrl = './Names/GetNames';  
        return this.http.get(dataUrl)
            .map(this.extractData)
            .catch(this.handleError);
    }

    // POST name to .NET and get a response.
    postName(nameObject: Object): Observable<Comment[]> {
        let headers = new Headers({ 'Content-Type': 'application/json' }); 
        let options = new RequestOptions({ headers: headers });
        let url     = './Names/GetFullName';
    
        return this.http.post(url, nameObject, options) 
            .map(this.extractData) 
            .catch(this.handleError); 
    } 

    // Retreival of JSON from .NET is a success.
    private extractData(res: Response) {
        let body = res.json();
        return body || {};
    }

    // An error occurred. Notify the user.
    private handleError(error: any) {
        let errMsg = (error.message) ? error.message :
            error.status ? `${error.status} - ${error.statusText}` : 'Server error';
        console.error(errMsg); // log to console instead
        return Observable.throw(errMsg);
    }
}