﻿var cm = new CookieMgr('mykey');
cm.setCookie("My Cookie Value");
alert(getCookie('mykey'));